import serial
import cv2
import numpy as np
import time

# --- CONFIGURACIÓN ---
PUERTO_SERIAL = '/dev/ttyUSB1' 
BAUD_RATE = 921600
# ---------------------

try:
    # timeout=0 permite lectura no bloqueante para máxima velocidad
    ser = serial.Serial(PUERTO_SERIAL, BAUD_RATE, timeout=0)
    #ser.set_buffer_size(rx_size=128000) # Buffer interno de Python más grande
    ser.reset_input_buffer()
    print(f"Conectado a {PUERTO_SERIAL} a {BAUD_RATE} baudios.")
except Exception as e:
    print(f"Error al abrir puerto: {e}")
    exit()

buffer = bytearray() # bytearray es más eficiente para concatenar que b''

while True:
    if ser.in_waiting > 0:
        # Leemos el bloque actual
        buffer.extend(ser.read(ser.in_waiting))

        # Buscamos inicio y fin
        start = buffer.find(b'\xff\xd8')
        if start != -1:
            # Tiramos basura antes del inicio
            if start > 0:
                del buffer[:start]
            
            end = buffer.find(b'\xff\xd9')
            if end != -1:
                # Extraemos el frame
                jpg_data = buffer[:end+2]
                # Borramos el frame procesado del buffer
                del buffer[:end+2]

                # Decodificar
                nparr = np.frombuffer(jpg_data, np.uint8)
                img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

                if img is not None:
                    # Agregamos FPS en pantalla para monitorear el rendimiento
                    cv2.putText(img, f"Streaming Activo", (10, 30), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                    cv2.imshow('Streaming Nodo 3 Final', img)
                else:
                    print("!", end="", flush=True)

    # El waitKey(1) es crítico para que OpenCV procese la ventana
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    
    # Si el buffer crece demasiado, algo va mal con la red
    if len(buffer) > 100000:
        buffer.clear()
        print("\n[INFO] Buffer purgado.")

print("\nCerrando conexión...")
ser.close()
cv2.destroyAllWindows()