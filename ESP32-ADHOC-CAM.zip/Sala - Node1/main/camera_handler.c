#include "camera_handler.h"
#include "esp_log.h"

static const char *TAG = "camera_handler";

esp_err_t init_camera() {
    camera_config_t config;
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer = LEDC_TIMER_0;
    config.pin_d0 = Y2_GPIO_NUM;
    config.pin_d1 = Y3_GPIO_NUM;
    config.pin_d2 = Y4_GPIO_NUM;
    config.pin_d3 = Y5_GPIO_NUM;
    config.pin_d4 = Y6_GPIO_NUM;
    config.pin_d5 = Y7_GPIO_NUM;
    config.pin_d6 = Y8_GPIO_NUM;
    config.pin_d7 = Y9_GPIO_NUM;
    config.pin_xclk = XCLK_GPIO_NUM;
    config.pin_pclk = PCLK_GPIO_NUM;
    config.pin_vsync = VSYNC_GPIO_NUM;
    config.pin_href = HREF_GPIO_NUM;
    config.pin_sscb_sda = SIOD_GPIO_NUM;
    config.pin_sscb_scl = SIOC_GPIO_NUM;
    config.pin_pwdn = PWDN_GPIO_NUM;
    config.pin_reset = RESET_GPIO_NUM;
    config.xclk_freq_hz = 20000000;
    config.pixel_format = PIXFORMAT_JPEG;

    // Usamos PSRAM para permitir resoluciones altas y estabilidad
    config.frame_size = FRAMESIZE_QVGA;  //FRAMESIZE_SVGA; // 640x480
    //Rango: 0 (mejor) → 63 (peor)
    config.jpeg_quality = 12;
    config.fb_count = 2; //2 buffers
    config.fb_location = CAMERA_FB_IN_PSRAM; 
    /*
    PSRAM permite:
Resoluciones más altas¡
Buffer doble (double buffering)
Streaming fluido
fb_count = 2
Mientras un frame se envía por HTTP
El otro se captura
    */

    esp_err_t err = esp_camera_init(&config);
    /*
    Aquí ocurre:
Reset del sensor
Configuración de registros
Reserva de buffers
Inicio del pipeline de captura
    */
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Camera init failed with error 0x%x", err);
        return err;
    }
    return ESP_OK;
}



/*
La Estrategia de Memoria: PSRAM y Double Buffering
Aquí es donde tu código se separa de los aficionados y entra en nivel experto:

fb_location = CAMERA_FB_IN_PSRAM: Estás moviendo el peso de la imagen a la memoria externa de 8MB. Esto libera la RAM interna del ESP32 (SRAM) para que el stack de WiFi y los Sockets UDP funcionen sin interrupciones.

fb_count = 2 (Double Buffering):

Funcionamiento: Mientras tu tarea de transmisión está ocupada leyendo el Frame A para enviarlo por pedazos al Pasillo, el hardware de la cámara ya está escribiendo el Frame B de forma independiente.

Resultado: Eliminas el parpadeo y aumentas los FPS. Nunca hay tiempo muerto donde la cámara esté "esperando" a que el WiFi termine.

-----------------------------------------------
La Caja Negra: esp_camera_init(&config)
Esta función es crítica. No solo "enciende" la cámara, sino que:

Configura el bus I2C (SCCB) para hablar con el sensor.

Configura el DMA (Direct Memory Access). El DMA es como un túnel que lleva los datos de la cámara a la PSRAM sin preguntarle a la CPU.

Si esta función falla, suele ser por voltaje. El sensor OV2640 consume picos de corriente justo en este milisegundo de inicio.


Resumen de experto: Este archivo está optimizado para baja latencia. Al delegar la compresión al hardware y usar doble buffer en la PSRAM, has convertido al ESP32 en un simple "pasamanos" de datos, que es exactamente lo que se necesita para un streaming fluido.

*/