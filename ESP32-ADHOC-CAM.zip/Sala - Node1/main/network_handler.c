#include "esp_wifi.h"
#include "esp_log.h"
#include "esp_event.h"
#include "lwip/sockets.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include <string.h>
#include <errno.h>

static const char *TAG = "network_handler";
static int sock = -1;
struct sockaddr_in dest_addr;

static EventGroupHandle_t wifi_event_group;
const int CONNECTED_BIT = BIT0;

#define WIFI_SSID      "RED_PASILLO"    
#define WIFI_PASS      "password123"
#define DEST_IP_ADDR   "192.168.5.1"    
#define DEST_PORT      5000

static void event_handler(void* arg, esp_event_base_t event_base,
                          int32_t event_id, void* event_data) {
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
        ESP_LOGI(TAG, "Buscando al Pasillo (%s)...", WIFI_SSID);
        esp_wifi_connect();
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        xEventGroupClearBits(wifi_event_group, CONNECTED_BIT);
        wifi_event_sta_disconnected_t* disconn = (wifi_event_sta_disconnected_t*) event_data;
        ESP_LOGW(TAG, "Desconectado (Razón: %d). Reintentando conexión...", disconn->reason);
        esp_wifi_connect();
    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
        ESP_LOGI(TAG, "¡Conectado! IP Cámara: " IPSTR " | Gateway: 192.168.5.1", IP2STR(&event->ip_info.ip));
        xEventGroupSetBits(wifi_event_group, CONNECTED_BIT);
    }
}

bool is_network_ready() {
    if (wifi_event_group == NULL) return false;
    return (xEventGroupGetBits(wifi_event_group) & CONNECTED_BIT);
}

void init_wifi_sta() {
    wifi_event_group = xEventGroupCreate();

    ESP_ERROR_CHECK(esp_netif_init());
    // Solo crea el loop si no ha sido creado previamente
    esp_err_t err = esp_event_loop_create_default();
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) ESP_ERROR_CHECK(err);

    esp_netif_t *my_netif = esp_netif_create_default_wifi_sta();

    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &event_handler, NULL, NULL));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &event_handler, NULL, NULL));

    // Configuración de IP Estática (Subred 5)
    esp_netif_dhcpc_stop(my_netif);
    esp_netif_ip_info_t ip_info;
    IP4_ADDR(&ip_info.ip, 192, 168, 5, 10);   
    IP4_ADDR(&ip_info.gw, 192, 168, 5, 1);    
    IP4_ADDR(&ip_info.netmask, 255, 255, 255, 0);
    esp_netif_set_ip_info(my_netif, &ip_info);

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    wifi_config_t wifi_config = {
        .sta = {
            .ssid = WIFI_SSID,
            .password = WIFI_PASS,
            // Sincronización de seguridad necesaria para conectar con el Pasillo
            .pmf_cfg = {
                .capable = true,
                .required = false
            },
        },
    };

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());
}

void init_udp_socket() {
    if (sock != -1) return; // Evitar crear múltiples sockets

    dest_addr.sin_addr.s_addr = inet_addr(DEST_IP_ADDR);
    dest_addr.sin_family = AF_INET;
    dest_addr.sin_port = htons(DEST_PORT);
    
    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
    if (sock < 0) {
        ESP_LOGE(TAG, "No se pudo crear el socket UDP: errno %d", errno);
    } else {
        ESP_LOGI(TAG, "Socket UDP creado para destino %s:%d", DEST_IP_ADDR, DEST_PORT);
    }
}

int send_udp_packet(uint8_t* data, size_t len) {
    if (sock < 0) {
        init_udp_socket();
        return -1;
    }
    
    if (!is_network_ready()) {
        return -1;
    }

    int sent = sendto(sock, data, len, 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
    if (sent < 0) {
        ESP_LOGE(TAG, "Error al enviar UDP: errno %d", errno);
    }
    return sent;
}

/*
El Mecanismo de Control: Event Groups
Línea: static EventGroupHandle_t wifi_event_group;

Análisis de Experto: El WiFi en el ESP32 no es instantáneo. Tarda segundos en autenticar y obtener IP. El EventGroup actúa como una bandera (flag) compartida entre el sistema operativo (FreeRTOS) y tu código.

El bit CONNECTED_BIT: Es el semáforo. La función is_network_ready() lo consulta. Si este bit no está en 1, la cámara no se atreve a enviar nada, evitando que el stack de red colapse por intentar usar recursos no listos.



-----------------------

En una red con PMF (Protected Management Frames), la conexión no es un evento estático; es una relación activa que requiere mantenimiento constante. El AP (Cuarto) envía pequeños paquetes invisibles de control para verificar que el cliente (Pasillo) sigue ahí y que su clave de cifrado sigue siendo válida
*/


