#include <string.h>
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_camera.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "camera_handler.h"
#include "network_protocol.h"
#include "network_handler.h"

static const char *TAG = "SALA_CAM_UDP";
static uint32_t global_frame_id = 0;

void camera_transmission_task(void *pvParameters) {
    ESP_LOGI(TAG, "Tarea de transmisión iniciada.");
    // Buffer: Encabezado + Datos del trozo
    static uint8_t send_buf[sizeof(mesh_video_header_t) + CHUNK_SIZE];
    
    while (1) {
        if (!is_network_ready()) {
            vTaskDelay(pdMS_TO_TICKS(500));
            continue;
        }

        camera_fb_t *fb = esp_camera_fb_get();
        if (!fb) {
            ESP_LOGW(TAG, "Fallo al capturar frame");
            continue;
        }

        global_frame_id++;
        uint16_t total_chunks = (fb->len + CHUNK_SIZE - 1) / CHUNK_SIZE;

        for (uint16_t i = 0; i < total_chunks; i++) {
            size_t offset = i * CHUNK_SIZE;
            uint32_t current_size = (fb->len - offset > CHUNK_SIZE) ? CHUNK_SIZE : (fb->len - offset);

            mesh_video_header_t header = {
                .magic = MESH_APP_TAG,
                .frame_id = global_frame_id,
                .chunk_idx = i,
                .total_chunks = total_chunks,
                .data_len = current_size
            };

            memcpy(send_buf, &header, sizeof(header));
            memcpy(send_buf + sizeof(header), fb->buf + offset, current_size);

            send_udp_packet(send_buf, sizeof(header) + current_size);
            
            // Delay crítico para no desbordar el socket del Nodo Pasillo
            vTaskDelay(pdMS_TO_TICKS(15)); 
        }

        esp_camera_fb_return(fb);
        ESP_LOGI(TAG, "Frame %lu enviado a Pasillo (%d trozos)", global_frame_id, total_chunks);
        
        // Control de FPS (aprox 10-15 FPS para estabilidad en la cadena)
        vTaskDelay(pdMS_TO_TICKS(150)); 
    }
}

void app_main(void) {
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    ESP_ERROR_CHECK(init_camera());
    init_wifi_sta();     
    init_udp_socket();   

    // Usamos el core 0 para asegurar compatibilidad total
    xTaskCreatePinnedToCore(camera_transmission_task, "cam_tx_task", 8192, NULL, 5, NULL, 1);
}


/*
Resumen de la Operación (Nodo 1)
Captura: El hardware llena la PSRAM vía DMA.

Segmentación: El CPU divide el JPEG en 10-12 partes.

Etiquetado: Se añade el 0x77 y el frame_id.

Dosificación: Se envían con pausas de 5ms para no ahogar al Pasillo.

*/