#ifndef NETWORK_HANDLER_H
#define NETWORK_HANDLER_H

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Inicializa el Wi-Fi en modo Estación (STA) con IP Estática.
 * Configura los manejadores de eventos para reconexión automática.
 Aquí no solo iniciamos el Wi-Fi, configuramos el Stack TCP/IP (LwIP).
 */
void init_wifi_sta(void);

/**
 * @brief Crea el socket UDP para la transmisión de video.
 */
void init_udp_socket(void);

/**
 * @brief Envía un paquete de datos por UDP al Nodo 2.
 * * @param data Puntero a los bytes a enviar.
 * @param len Tamaño del paquete.
 * @return int Número de bytes enviados, o -1 si falla.
 */
int send_udp_packet(uint8_t* data, size_t len);

/**
 * @brief Consulta si la red está lista para transmitir.
 * * @return true Si está conectado al Nodo 2 y tiene IP estática activa.
 * @return false Si está desconectado o buscando red.
 */
bool is_network_ready(void);

#ifdef __cplusplus
}
#endif

#endif // NETWORK_HANDLER_H