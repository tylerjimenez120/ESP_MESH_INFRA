#include "nvs_flash.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "pasillo_handler.h"
#include "esp_log.h"

void app_main(void) {
    // 1. Inicializar almacenamiento persistente
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    // 2. Iniciar WiFi en modo Bridge (AP + STA)
    init_wifi_bridge_pasillo();

    // 3. Crear la tarea de reenvío UDP en el Core 1
    // Usamos 4KB de stack para que el manejo de sockets sea seguro
    xTaskCreatePinnedToCore(
        forward_task,    // Función de la tarea
        "forward_task",  // Nombre
        4096,            // Stack (bytes)
        NULL,            // Parámetros
        10,              // Prioridad
        NULL,            // Handle
        1                // Núcleo (Core 1)
    );

    ESP_LOGI("MAIN", "Nodo Pasillo iniciado correctamente.");
}