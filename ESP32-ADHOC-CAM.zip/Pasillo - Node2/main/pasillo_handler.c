#include "pasillo_handler.h"
#include "esp_wifi.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "lwip/sockets.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>
#include <errno.h>

static const char *TAG = "PASILLO_NODE";

static void wifi_event_handler(void* arg, esp_event_base_t event_base,
                             int32_t event_id, void* event_data) {
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
        ESP_LOGI(TAG, "WiFi STA iniciado. Conectando al Cuarto...");
        esp_wifi_connect();
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        wifi_event_sta_disconnected_t* disconn = (wifi_event_sta_disconnected_t*) event_data;
        ESP_LOGW(TAG, "Desconectado del Cuarto (Razón: %d). Reintentando...", disconn->reason);
        esp_wifi_connect();
    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
        ESP_LOGI(TAG, "¡Enlace con Cuarto OK! IP asignada: " IPSTR, IP2STR(&event->ip_info.ip));
    }
}

void init_wifi_bridge_pasillo(void) {
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    esp_netif_t *sta_netif = esp_netif_create_default_wifi_sta();
    esp_netif_t *ap_netif = esp_netif_create_default_wifi_ap();

    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL, NULL));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &wifi_event_handler, NULL, NULL));

    // 1. IP Estática para conectar al CUARTO (Subred 4)
    esp_netif_dhcpc_stop(sta_netif);
    esp_netif_ip_info_t sta_ip;
    IP4_ADDR(&sta_ip.ip, 192, 168, 4, 2);      
    IP4_ADDR(&sta_ip.gw, 192, 168, 4, 1);      
    IP4_ADDR(&sta_ip.netmask, 255, 255, 255, 0);
    esp_netif_set_ip_info(sta_netif, &sta_ip);

    // 2. IP Estática para recibir de la SALA (Subred 5)
    esp_netif_dhcps_stop(ap_netif);
    esp_netif_ip_info_t ap_ip;
    IP4_ADDR(&ap_ip.ip, 192, 168, 5, 1);       
    IP4_ADDR(&ap_ip.gw, 192, 168, 5, 1);
    IP4_ADDR(&ap_ip.netmask, 255, 255, 255, 0);
    esp_netif_set_ip_info(ap_netif, &ap_ip);
    esp_netif_dhcps_start(ap_netif);

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    wifi_config_t sta_config = {
        .sta = {
            .ssid = CUARTO_SSID,
            .password = CUARTO_PASS,
            .pmf_cfg = { .capable = true, .required = false },
        },
    };

    wifi_config_t ap_config = {
        .ap = {
            .ssid = PASILLO_SSID,
            .ssid_len = strlen(PASILLO_SSID),
            .password = PASILLO_PASS,
            .max_connection = 4,
            .authmode = WIFI_AUTH_WPA2_PSK, 
            .channel = 1 
        },
    };

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_APSTA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &sta_config));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &ap_config));
    ESP_ERROR_CHECK(esp_wifi_start());
}

void forward_task(void *pvParameters) {
    uint8_t *buffer = malloc(BUF_SIZE);
    if (buffer == NULL) {
        ESP_LOGE(TAG, "Error: No hay memoria para el buffer");
        vTaskDelete(NULL);
    }

    struct sockaddr_in dest_addr;
    dest_addr.sin_addr.s_addr = inet_addr(CUARTO_IP);
    dest_addr.sin_family = AF_INET;
    dest_addr.sin_port = htons(UDP_PORT);

    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
    if (sock < 0) {
        ESP_LOGE(TAG, "No se pudo crear el socket: errno %d", errno);
        free(buffer);
        vTaskDelete(NULL);
    }

    // --- AQUÍ VA LA MEJORA ---
    // Aumentamos el buffer de recepción del socket a 10KB o 20KB
    // Esto es vital en el Pasillo para aguantar ráfagas de video sin pérdida.
    int rcv_size = 20 * 1024; 
    setsockopt(sock, SOL_SOCKET, SO_RCVBUF, &rcv_size, sizeof(rcv_size));
    // -------

    struct sockaddr_in bind_addr;
    bind_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    bind_addr.sin_family = AF_INET;
    bind_addr.sin_port = htons(UDP_PORT);
    
    if (bind(sock, (struct sockaddr *)&bind_addr, sizeof(bind_addr)) < 0) {
        ESP_LOGE(TAG, "Error en bind: errno %d", errno);
        close(sock);
        free(buffer);
        vTaskDelete(NULL);
    }

    ESP_LOGI(TAG, ">>> PUENTE ACTIVO: Escuchando Sala y reenviando a %s", CUARTO_IP);

    uint32_t pkt_count = 0;
    while (1) {
        struct sockaddr_in source_addr;
        socklen_t addr_len = sizeof(source_addr);
        
        // Recibir paquete de la Sala
        int len = recvfrom(sock, buffer, BUF_SIZE, 0, (struct sockaddr *)&source_addr, &addr_len);
        
        if (len > 0) {
            // Reenviar inmediatamente al Cuarto
            sendto(sock, buffer, len, 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
            
            pkt_count++;
            if (pkt_count % 100 == 0) {
                ESP_LOGI(TAG, "Video fluyendo: %lu paquetes procesados desde %s", 
                         pkt_count, inet_ntoa(source_addr.sin_addr));
            }
        } else if (len < 0) {
            ESP_LOGE(TAG, "Error en recvfrom: errno %d", errno);
            vTaskDelay(pdMS_TO_TICKS(10));
        }
    }
    
    close(sock);
    free(buffer);
    vTaskDelete(NULL); 
}

/*



Resumen de Operación (Nodo 2)
Recibe: Escucha en 192.168.5.1:5000 (Subred Sala).

Duplica: Mantiene el paquete en RAM exactamente como llegó.

Dispara: Lo envía a 192.168.4.1:5000 (Subred Cuarto).

Repite: El C6 hace esto miles de veces por minuto sin cansarse.
*/
