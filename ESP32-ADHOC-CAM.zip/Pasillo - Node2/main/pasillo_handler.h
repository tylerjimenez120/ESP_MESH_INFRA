#ifndef PASILLO_HANDLER_H
#define PASILLO_HANDLER_H

#include "esp_err.h"

#define CUARTO_SSID      "RED_CUARTO"
#define CUARTO_PASS      "password123"
#define CUARTO_IP        "192.168.4.1"

#define PASILLO_SSID     "RED_PASILLO"
#define PASILLO_PASS     "password123"

#define UDP_PORT         5000
#define BUF_SIZE         1500

// Funciones limpias
void init_wifi_bridge_pasillo(void);
void forward_task(void *pvParameters);

#endif