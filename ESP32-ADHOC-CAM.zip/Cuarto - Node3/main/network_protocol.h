#pragma once
#include <stdint.h>

#define MESH_APP_TAG 0x77  // Identificador de la app - filtro de hardware/software rapido
#define CHUNK_SIZE 1000    // Tamaño de trozo para no fragmentar a nivel IP

typedef struct __attribute__((packed)) {
    uint8_t magic;         // MESH_APP_TAG - sello de autenticidad
    uint32_t frame_id;     // ID incremental - frame es la foto - id es el identificador de la foto
    uint16_t chunk_idx;    // Índice del trozo - 
    uint16_t total_chunks; // Total de trozos
    uint32_t data_len;     // Tamaño del payload
} mesh_video_header_t;



/*
La Estructura: mesh_video_header_t
Aquí es donde ocurre la magia de la reconstrucción. Analicemos los campos del struct:

uint8_t magic: Ya lo vimos, es el sello de autenticidad.

uint32_t frame_id: Crucial para el video. Le dice al receptor: "Este trozo pertenece a la foto número 500". Si llega un trozo de la foto 499 tarde, el receptor sabe que debe tirarlo.

uint16_t chunk_idx y total_chunks: Permiten reconstruir el rompecabezas. El receptor sabe que si total_chunks es 10, debe esperar desde el índice 0 hasta el 9 para armar la imagen completa.

uint32_t data_len: No todos los trozos miden 1,000 bytes. El último trozo de una imagen suele ser más pequeño. Este campo le dice al UART exactamente cuántos bytes reales de imagen debe escribir.

---------------------------------------------------------------

El modificador crítico: __attribute__((packed))
Análisis de Bajo Nivel: Por defecto, los procesadores de 32 bits (como el RISC-V del C6) intentan alinear los datos en múltiplos de 4 bytes para ser más rápidos. Esto se llama Padding.

Sin este atributo: El compilador podría meter un "byte vacío" después de uint8_t magic para que el uint32_t frame_id empiece en una dirección de memoria par.

Con __attribute__((packed)): Le ordenas al compilador: "No metas espacios vacíos". Esto garantiza que el encabezado mida exactamente 13 bytes (1+4+2+2+4) en los tres nodos. Si un nodo usa padding y otro no, la comunicación se rompe totalmente.


----------------------------------------------------------------

Resumen de experto: Este encabezado es un protocolo de Capa 7 (Aplicación) que corre sobre UDP. Su diseño prioriza la velocidad de descarte y la integridad de la reconstrucción de archivos binarios (JPEG).

*/