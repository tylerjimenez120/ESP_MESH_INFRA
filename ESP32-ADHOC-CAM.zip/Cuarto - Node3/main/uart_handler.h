#ifndef UART_HANDLER_H
#define UART_HANDLER_H

#include "esp_err.h"
#include "driver/gpio.h"

// Configuración de red (Cuarto como AP)
#define CUARTO_SSID      "RED_CUARTO"
#define CUARTO_PASS      "password123"
#define UDP_PORT         5000
#define BUF_SIZE         1500

// Configuración UART2 para VIDEO (Pines sugeridos para ESP32)
#define VIDEO_UART_NUM   UART_NUM_2
#define VIDEO_TX_PIN     GPIO_NUM_17  // Conectar al RX del adaptador USB
#define VIDEO_RX_PIN     GPIO_NUM_16  // Conectar al TX del adaptador USB (opcional)

void init_video_uart(void);
void init_wifi_ap_cuarto(void);
void start_udp_to_uart_task(void);

#endif