#include "uart_handler.h"
#include "esp_wifi.h"
#include "esp_log.h"
#include "network_protocol.h"
#include "lwip/sockets.h"
#include "driver/uart.h"
#include "esp_netif.h"
#include <string.h>
#include <errno.h>

static const char *TAG = "CUARTO_NODE";

void init_video_uart() {
    uart_config_t uart_config = {
        .baud_rate = 921600, 
        .data_bits = UART_DATA_8_BITS,
        .parity    = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    
    // Configuración de UART2 con buffers generosos para video (6KB de buffer)
    ESP_ERROR_CHECK(uart_param_config(VIDEO_UART_NUM, &uart_config));
    ESP_ERROR_CHECK(uart_set_pin(VIDEO_UART_NUM, VIDEO_TX_PIN, VIDEO_RX_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    // Cambio: Subimos a 12KB o 16KB de buffer de envío UART
    ESP_ERROR_CHECK(uart_driver_install(VIDEO_UART_NUM, 16384, 0, 0, NULL, 0));
    
    ESP_LOGI(TAG, "UART2 iniciado (TX:%d) a 921600 bps para salida de video.", VIDEO_TX_PIN);
}

void init_wifi_ap_cuarto() {
    ESP_ERROR_CHECK(esp_netif_init());
    esp_err_t err = esp_event_loop_create_default();
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
        ESP_ERROR_CHECK(err);
    }
    
    esp_netif_t *ap_netif = esp_netif_create_default_wifi_ap();

    // IP Estática para el Nodo Receptor (Gateway de la red)
    esp_netif_dhcps_stop(ap_netif);
    esp_netif_ip_info_t ip_info;
    IP4_ADDR(&ip_info.ip, 192, 168, 4, 1);
    IP4_ADDR(&ip_info.gw, 192, 168, 4, 1);
    IP4_ADDR(&ip_info.netmask, 255, 255, 255, 0);
    esp_netif_set_ip_info(ap_netif, &ip_info);
    esp_netif_dhcps_start(ap_netif);

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    wifi_config_t wifi_config = {
        .ap = {
            .ssid = CUARTO_SSID,
            .ssid_len = strlen(CUARTO_SSID),
            .password = CUARTO_PASS,
            .max_connection = 4,
            .authmode = WIFI_AUTH_WPA2_PSK,
            .channel = 1,
            .pmf_cfg = {
                .required = false,
            },
        },
    };

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());
    
    ESP_LOGI(TAG, "Nodo Cuarto (AP) activo en 192.168.4.1 (Canal 1)");
}

void udp_to_uart_task(void *pvParameters) {
    uint8_t *rx_buffer = (uint8_t *)malloc(BUF_SIZE);
    if (rx_buffer == NULL) {
        ESP_LOGE(TAG, "Fallo malloc");
        vTaskDelete(NULL);
    }

    struct sockaddr_in server_addr;
    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
    if (sock < 0) {
        ESP_LOGE(TAG, "Error socket: %d", errno);
        free(rx_buffer);
        vTaskDelete(NULL);
    }
    
    int rcv_size = 20 * 1024;
    setsockopt(sock, SOL_SOCKET, SO_RCVBUF, &rcv_size, sizeof(rcv_size));

    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(UDP_PORT);
    
    if (bind(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        ESP_LOGE(TAG, "Error bind: %d", errno);
        close(sock);
        free(rx_buffer);
        vTaskDelete(NULL);
    }

    ESP_LOGI(TAG, "Escuchando video en puerto %d (Tag: 0x%02X)...", UDP_PORT, MESH_APP_TAG);

    while (1) {
        struct sockaddr_in source_addr;
        socklen_t addr_len = sizeof(source_addr);
        
        int len = recvfrom(sock, rx_buffer, BUF_SIZE, 0, (struct sockaddr *)&source_addr, &addr_len);
        
        // Verificamos que al menos llegue el tamaño del header
        if (len >= sizeof(mesh_video_header_t)) {
            
            // VALIDACIÓN POR BYTE: Comparamos el primer byte con 0x77
            if (rx_buffer[0] == (uint8_t)MESH_APP_TAG) {
                
                mesh_video_header_t *header = (mesh_video_header_t *)rx_buffer;
                
                // El payload de video empieza justo después del header
                uint8_t *video_payload = rx_buffer + sizeof(mesh_video_header_t);
                
                // Enviar al UART2 los datos puros del JPG
                uart_write_bytes(VIDEO_UART_NUM, (const char *)video_payload, header->data_len);
                // Fuerza al hardware a vaciar el buffer hacia el FTDI antes de seguir
                uart_wait_tx_done(VIDEO_UART_NUM, pdMS_TO_TICKS(50));
                
                // Log de progreso para confirmar que el video fluye desde el Pasillo (192.168.4.2)
                if (header->chunk_idx == 0) {
                    ESP_LOGI(TAG, "RECIBIDO: Frame %lu | Origen: %s", 
                             header->frame_id, inet_ntoa(source_addr.sin_addr));
                }
            } else {
                // Si el Pasillo reenvía algo que no empieza con 0x77, lo avisamos
                ESP_LOGD(TAG, "Paquete con Tag inválido: 0x%02X", rx_buffer[0]);
            }
        }
    }
    
    close(sock);
    free(rx_buffer);
}

void start_udp_to_uart_task() {
    // Core 1 para no saturar el stack WiFi en el Core 0
    xTaskCreatePinnedToCore(udp_to_uart_task, "u2u_task", 4096, NULL, 10, NULL, 1);
}


/*
Resumen de Operación (Nodo 3)
Escucha: Atrapada el paquete del aire desde el Pasillo (192.168.4.2).

Valida: Revisa el primer byte. ¿Es 0x77? Si no, lo ignora.

Pela: Desecha los 13 bytes de encabezado.

Serializa: Envía los bytes puros a 921,600 baudios por el Pin 17.
*/